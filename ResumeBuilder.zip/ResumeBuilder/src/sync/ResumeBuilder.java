package sync;

import java.io.FileOutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.Scanner;

public class ResumeBuilder {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Resume Builder!");

        // Get user input for the resume details
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your email: ");
        String email = scanner.nextLine();

        System.out.print("Enter your phone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.print("Enter your education: ");
        String education = scanner.nextLine();

        System.out.print("Enter your work experience: ");
        String workExperience = scanner.nextLine();

        System.out.print("Enter your skills (comma-separated): ");
        String skills = scanner.nextLine();

        System.out.print("Enter your projects (comma-separated): ");
        String projects = scanner.nextLine();

        System.out.print("Enter your interests (comma-separated): ");
        String interests = scanner.nextLine();

        // Create the resume
        Resume resume = new Resume(name, email, phoneNumber, education, workExperience, skills, projects, interests);

        // Print the resume details
        System.out.println("\nHere's your resume:");
        System.out.println(resume);

        // Generate the PDF and save it
        String pdfFilePath = "resume.pdf";
        generateResumePDF(resume, pdfFilePath);

        System.out.println("\nYour resume has been saved as a PDF: " + pdfFilePath);
    }

    private static void generateResumePDF(Resume resume, String pdfFilePath) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(pdfFilePath));
            document.open();

            // Create a title font for the resume
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20);
            // Create a section font for headings
            Font sectionFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);

            // Add title to the resume
            Paragraph title = new Paragraph("Resume", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Add personal information
            document.add(new Paragraph("\nName: " + resume.getName()));
            document.add(new Paragraph("Email: " + resume.getEmail()));
            document.add(new Paragraph("Phone: " + resume.getPhoneNumber()));

            // Add education section
            document.add(new Paragraph("\nEducation", sectionFont));
            document.add(new Paragraph(resume.getEducation()));

            // Add work experience section
            document.add(new Paragraph("\nWork Experience", sectionFont));
            document.add(new Paragraph(resume.getWorkExperience()));

            // Add skills section
            document.add(new Paragraph("\nSkills", sectionFont));
            document.add(new Paragraph(resume.getSkills()));

            // Add projects section
            document.add(new Paragraph("\nProjects", sectionFont));
            document.add(new Paragraph(resume.getProjects()));

            // Add interests section
            document.add(new Paragraph("\nInterests", sectionFont));
            document.add(new Paragraph(resume.getInterests()));

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class Resume {
    private String name;
    private String email;
    private String phoneNumber;
    private String education;
    private String workExperience;
    private String skills;
    private String projects;
    private String interests;

    public Resume(String name, String email, String phoneNumber, String education, String workExperience, String skills, String projects, String interests) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.education = education;
        this.workExperience = workExperience;
        this.skills = skills;
        this.projects = projects;
        this.interests = interests;
    }

    // Getters for the resume fields
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEducation() {
        return education;
    }

    public String getWorkExperience() {
        return workExperience;
    }

    public String getSkills() {
        return skills;
    }

    public String getProjects() {
        return projects;
    }

    public String getInterests() {
        return interests;
    }
}
